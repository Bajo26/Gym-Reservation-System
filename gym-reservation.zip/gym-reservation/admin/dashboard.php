<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

require '../config/database.php';

// Functions to retrieve data
function getUsers($pdo) {
    $stmt = $pdo->query('SELECT * FROM users');
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getReservations($pdo) {
    $stmt = $pdo->query('SELECT * FROM reservations');
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getReports($pdo) {
    $stmt = $pdo->query('SELECT * FROM reports');
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function sendNotification($pdo, $message, $recipients) {
    $stmt = $pdo->prepare('INSERT INTO notifications (message, recipient_id) VALUES (?, ?)');
    foreach ($recipients as $recipient_id) {
        $stmt->execute([$message, $recipient_id]);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        .btn-box {
            display: inline-block;
            padding: 10px 20px;
            border: 2px solid #007bff;
            border-radius: 4px;
            background-color: #fff;
            color: #007bff;
            text-align: center;
            font-weight: bold;
            transition: background-color 0.3s, color 0.3s;
        }
        .btn-box:hover {
            background-color: #007bff;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1 class="mb-4">Admin Dashboard</h1>

        <!-- Logout Button -->
        <a href="../logout.php" class="btn btn-danger btn-box mb-4">Logout</a>

        <!-- Navigation Tabs -->
        <ul class="nav nav-tabs" id="dashboardTabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active btn-box" id="user-management-tab" data-toggle="tab" href="#user-management" role="tab" aria-controls="user-management" aria-selected="true">User Management</a>
            </li>
            <li class="nav-item">
                <a class="nav-link btn-box" id="reservations-overview-tab" data-toggle="tab" href="#reservations-overview" role="tab" aria-controls="reservations-overview" aria-selected="false">Reservations Overview</a>
            </li>
            <li class="nav-item">
                <a class="nav-link btn-box" id="workouts-management-tab" data-toggle="tab" href="#workouts-management" role="tab" aria-controls="workouts-management" aria-selected="false">Workouts Management</a>
            </li>
            <li class="nav-item">
            <a class="nav-link btn-box" id="gender-stats-tab" data-toggle="tab" href="#gender-stats" role="tab" aria-controls="gender-stats" aria-selected="false">Gender Statistics</a>
            </li>
            <li class="nav-item">
                <a class="nav-link btn-box" id="reports-analytics-tab" data-toggle="tab" href="#reports-analytics" role="tab" aria-controls="reports-analytics" aria-selected="false">Reports and Analytics</a>
            </li>
            <li class="nav-item">
                <a class="nav-link btn-box" id="notifications-tab" data-toggle="tab" href="#notifications" role="tab" aria-controls="notifications" aria-selected="false">Notifications</a>
            </li>
            <li class="nav-item">
                <a class="nav-link btn-box" id="settings-tab" data-toggle="tab" href="#settings" role="tab" aria-controls="settings" aria-selected="false">Settings</a>
            </li>
        </ul>

        <!-- Tab Panes -->
        <div class="tab-content" id="dashboardTabsContent">
            <!-- User Management -->
            <div class="tab-pane fade show active" id="user-management" role="tabpanel" aria-labelledby="user-management-tab">
                <h2 class="mt-4">User Management</h2>
                <a href="add_user.php" class="btn btn-primary btn-box mb-3">Add User</a>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>Name</th>
                            <th>Role</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $users = getUsers($pdo);
                        foreach ($users as $user) {
                            echo "<tr>
                                    <td>{$user['id']}</td>
                                    <td>{$user['username']}</td>
                                    <td>{$user['role']}</td>
                                    <td>
                                        <a href='edit_user.php?id={$user['id']}' class='btn btn-warning btn-box btn-sm'>Edit</a>
                                        <a href='delete_user.php?id={$user['id']}' class='btn btn-danger btn-box btn-sm'>Delete</a>
                                    </td>
                                  </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- Reservations Overview -->
            <div class="tab-pane fade" id="reservations-overview" role="tabpanel" aria-labelledby="reservations-overview-tab">
                <h2 class="mt-4">Reservations Overview</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Reservation ID</th>
                            <th>Member</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $reservations = getReservations($pdo);
                        foreach ($reservations as $reservation) {
                            echo "<tr>
                                    <td>{$reservation['id']}</td>
                                    <td>{$reservation['member_id']}</td>
                                    <td>{$reservation['reservation_time']}</td>
                                    <td>{$reservation['status']}</td>
                                    <td>
                                        <a href='edit_reservation.php?id={$reservation['id']}' class='btn btn-warning btn-box btn-sm'>Edit</a>
                                        <a href='delete_reservation.php?id={$reservation['id']}' class='btn btn-danger btn-box btn-sm'>Delete</a>
                                    </td>
                                  </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- Workouts Management Tab Content -->
            <div class="tab-pane fade" id="workouts-management" role="tabpanel" aria-labelledby="workouts-management-tab">
                <h2 class="mt-4">Workouts Management</h2>
                <a href="add_workout.php" class="btn btn-primary btn-box mb-3">Add Workout</a>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Workout ID</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        function getWorkouts($pdo) {
                            $stmt = $pdo->query('SELECT * FROM workouts');
                            return $stmt->fetchAll(PDO::FETCH_ASSOC);
                        }

                        $workouts = getWorkouts($pdo);
                        foreach ($workouts as $workout) {
                            echo "<tr>
                                    <td>{$workout['id']}</td>
                                    <td>{$workout['name']}</td>
                                    <td>{$workout['category']}</td>
                                    <td>
                                        <a href='edit_workout.php?id={$workout['id']}' class='btn btn-warning btn-box btn-sm'>Edit</a>
                                        <a href='delete_workout.php?id={$workout['id']}' class='btn btn-danger btn-box btn-sm'>Delete</a>
                                    </td>
                                </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- Gender Statistics Tab Content -->
            <div class="tab-pane fade" id="gender-stats" role="tabpanel" aria-labelledby="gender-stats-tab">
                <h2 class="mt-4">Gender Statistics</h2>
                <canvas id="genderChart"></canvas>
                <script>
                    // Fetch gender data and render the chart
                    document.addEventListener('DOMContentLoaded', function () {
                        fetch('get_gender_stats.php')
                            .then(response => response.json())
                            .then(data => {
                                const ctx = document.getElementById('genderChart').getContext('2d');
                                new Chart(ctx, {
                                    type: 'bar',
                                    data: {
                                        labels: ['Male', 'Female'],
                                        datasets: [{
                                            label: 'Number of Users',
                                            data: [data.male, data.female],
                                            backgroundColor: ['rgba(54, 162, 235, 0.2)', 'rgba(255, 99, 132, 0.2)'],
                                            borderColor: ['rgba(54, 162, 235, 1)', 'rgba(255, 99, 132, 1)'],
                                            borderWidth: 1
                                        }]
                                    },
                                    options: {
                                        scales: {
                                            y: {
                                                beginAtZero: true
                                            }
                                        }
                                    }
                                });
                            });
                    });
                </script>
            </div>


            <!-- Reports and Analytics -->
            <div class="tab-pane fade" id="reports-analytics" role="tabpanel" aria-labelledby="reports-analytics-tab">
                <h2 class="mt-4">Reports and Analytics</h2>
                <a href="generate_report.php" class="btn btn-primary btn-box mb-3">Generate Report</a>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Report ID</th>
                            <th>Report Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $reports = getReports($pdo);
                        foreach ($reports as $report) {
                            echo "<tr>
                                    <td>{$report['id']}</td>
                                    <td>{$report['report_name']}</td>
                                    <td>
                                        <a href='view_report.php?id={$report['id']}' class='btn btn-info btn-box btn-sm'>View</a>
                                        <a href='delete_report.php?id={$report['id']}' class='btn btn-danger btn-box btn-sm'>Delete</a>
                                    </td>
                                  </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Notifications -->
            <div class="tab-pane fade" id="notifications" role="tabpanel" aria-labelledby="notifications-tab">
                <h2 class="mt-4">Notifications</h2>
                <form action="send_notification.php" method="post">
                    <div class="form-group">
                        <textarea class="form-control" name="message" placeholder="Enter notification message" required></textarea>
                    </div>
                    <div class="form-group">
                        <select class="form-control" name="role" required>
                            <option value="">Select Role</option>
                            <option value="all">All Users</option>
                            <option value="member">Members</option>
                            <option value="coach">Coaches</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary btn-box">Send Notification</button>
                </form>
                <div class="tab-pane fade" id="notifications" role="tabpanel" aria-labelledby="notifications-tab">
                <h2 class="mt-4">Admin Notifications</h2>
                <?php
                function getNotifications($pdo) {
                    $stmt = $pdo->query('SELECT * FROM notif ORDER BY created_at DESC');
                    return $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
                
                $notifications = getNotifications($pdo);
                if ($notifications) {
                    echo '<ul class="list-group">';
                    foreach ($notifications as $notification) {
                        echo "<li class='list-group-item'>
                                <p><strong>Message:</strong> {$notification['message']}</p>
                                <p><strong>Recipient ID:</strong> {$notification['recipient_id']}</p>
                                <p><strong>Time:</strong> {$notification['created_at']}</p>
                            </li>";
                    }
                    echo '</ul>';
                } else {
                    echo '<p>No notifications available.</p>';
                }
                ?>
            </div>
            </div>
            


            <!-- Settings -->
            <div class="tab-pane fade" id="settings" role="tabpanel" aria-labelledby="settings-tab">
                <h2 class="mt-4">Settings</h2>
                <form action="update_settings.php" method="post">
                    <div class="form-group">
                        <label for="operational_hours">Operational Hours:</label>
                        <input type="text" class="form-control" id="operational_hours" name="operational_hours" required>
                    </div>
                    <div class="form-group">
                        <label for="notification_preferences">Notification Preferences:</label>
                        <input type="text" class="form-control" id="notification_preferences" name="notification_preferences" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-box">Save Settings</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
