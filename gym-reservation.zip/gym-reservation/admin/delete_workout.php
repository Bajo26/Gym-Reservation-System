<?php
require '../config/database.php';

$id = $_GET['id'];

$stmt = $pdo->prepare('DELETE FROM workouts WHERE id = ?');
$stmt->execute([$id]);

header('Location: ./dashboard.php');
exit;
?>
