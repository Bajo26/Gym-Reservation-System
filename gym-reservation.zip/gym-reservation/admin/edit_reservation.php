<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

require '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $status = $_POST['status'];

    $stmt = $pdo->prepare('UPDATE reservations SET status = ? WHERE id = ?');
    $stmt->execute([$status, $id]);

    header('Location: ./dashboard.php');
    exit;
}

$id = $_GET['id'];
$stmt = $pdo->prepare('SELECT * FROM reservations WHERE id = ?');
$stmt->execute([$id]);
$reservation = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Reservation</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Edit Reservation</h1>
        <form action="edit_reservation.php" method="post">
            <input type="hidden" name="id" value="<?php echo $reservation['id']; ?>">
            <div class="form-group">
                <label for="status">Status</label>
                <select class="form-control" id="status" name="status" required>
                    <option value="pending" <?php echo $reservation['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="accepted" <?php echo $reservation['status'] === 'accepted' ? 'selected' : ''; ?>>Accepted</option>
                    <option value="declined" <?php echo $reservation['status'] === 'declined' ? 'selected' : ''; ?>>Declined</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Update Reservation</button>
            <a href="./dashboard.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>
