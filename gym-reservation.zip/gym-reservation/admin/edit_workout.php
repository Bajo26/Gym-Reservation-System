<?php
require '../config/database.php';

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $category = $_POST['category'];

    $stmt = $pdo->prepare('UPDATE workouts SET name = ?, category = ? WHERE id = ?');
    $stmt->execute([$name, $category, $id]);

    header('Location: ./dashboard.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM workouts WHERE id = ?');
$stmt->execute([$id]);
$workout = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Workout</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #f8f9fa;
        }
        .btn-box {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1 class="text-center mb-4">Edit Workout</h1>
        <div class="form-container">
            <form action="edit_workout.php?id=<?php echo htmlspecialchars($id); ?>" method="post">
                <div class="form-group">
                    <label for="name">Workout Name:</label>
                    <input type="text" id="name" name="name" class="form-control" value="<?php echo htmlspecialchars($workout['name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="category">Category:</label>
                    <input type="text" id="category" name="category" class="form-control" value="<?php echo htmlspecialchars($workout['category']); ?>" required>
                </div>
                <button type="submit" class="btn btn-warning btn-box">Update Workout</button>
                <a href="./dashboard.php" class="btn btn-secondary btn-box">Back to Dashboard</a>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
