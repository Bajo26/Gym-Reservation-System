<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

require '../config/database.php';

// Function to fetch data for the report
function fetchReportData($pdo) {
    $stmt = $pdo->query('SELECT * FROM reservations'); // Adjust query based on your report requirements
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Generate CSV report
function generateCSV($data) {
    $filename = 'report_' . date('YmdHis') . '.csv';
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

    $output = fopen('php://output', 'w');
    if (!empty($data)) {
        // Output column headings
        fputcsv($output, array_keys($data[0]));
        // Output data rows
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
    }
    fclose($output);
    exit;
}

$data = fetchReportData($pdo);
generateCSV($data);
?>
