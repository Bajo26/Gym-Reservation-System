<?php
require '../config/database.php';

function getGenderStats($pdo) {
    $stmt = $pdo->query('
        SELECT gender, COUNT(*) as count 
        FROM users 
        GROUP BY gender
    ');
    $stats = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $genderStats = ['male' => 0, 'female' => 0];
    foreach ($stats as $stat) {
        $genderStats[$stat['gender']] = $stat['count'];
    }
    return $genderStats;
}

header('Content-Type: application/json');
echo json_encode(getGenderStats($pdo));
?>
