<?php
session_start();
require 'config/database.php';

if ($_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

$coach_id = $_SESSION['user_id'];

// Fetch coach profile info
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$coach_id]);
$coach = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $bio = $_POST['bio'];
    $contact_info = $_POST['contact_info'];

    // Update profile info
    $stmt = $pdo->prepare("UPDATE users SET bio = ?, contact_info = ? WHERE id = ?");
    $stmt->execute([$bio, $contact_info, $coach_id]);

    // Handle profile picture upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $profile_picture = 'uploads/' . basename($_FILES['profile_picture']['name']);
        move_uploaded_file($_FILES['profile_picture']['tmp_name'], $profile_picture);

        $stmt = $pdo->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
        $stmt->execute([$profile_picture, $coach_id]);
    }

    header('Location: profile.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile Info</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h2>Profile Info</h2>
    
    <form method="POST" enctype="multipart/form-data">
        <label>Profile Picture:</label><br>
        <img src="<?= $coach['profile_picture'] ?>" alt="Profile Picture" width="150"><br>
        <input type="file" name="profile_picture"><br><br>

        <label>Bio:</label><br>
        <textarea name="bio"><?= $coach['bio'] ?></textarea><br><br>

        <label>Contact Info:</label><br>
        <input type="text" name="contact_info" value="<?= $coach['contact_info'] ?>"><br><br>

        <button type="submit">Update Profile</button>
    </form>

    <a href="coach_dashboard.php" class="button">Back to Dashboard</a>
</body>
</html>
