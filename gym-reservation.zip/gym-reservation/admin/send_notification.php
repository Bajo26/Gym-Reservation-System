<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

require '../config/database.php';

// Function to send notifications
function sendNotification($pdo, $message, $recipients) {
    $stmt = $pdo->prepare('INSERT INTO notif (message, recipient_id) VALUES (?, ?)');
    foreach ($recipients as $recipient_id) {
        $stmt->execute([$message, $recipient_id]);
    }
}

// Function to get user IDs based on role
function getUserIdsByRole($pdo, $role) {
    $stmt = $pdo->prepare('SELECT id FROM users WHERE role = ?');
    $stmt->execute([$role]);
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

// Function to get all user IDs
function getAllUserIds($pdo) {
    $stmt = $pdo->query('SELECT id FROM users');
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the notification message and role from the form
    $message = $_POST['message'];
    $role = $_POST['role'];

    // Determine recipients based on role
    $recipients = [];
    if ($role === 'all') {
        $recipients = getAllUserIds($pdo);
    } elseif ($role === 'member' || $role === 'coach') {
        $recipients = getUserIdsByRole($pdo, $role);
    }

    // Check if recipients are found
    if (empty($recipients)) {
        $_SESSION['notification_status'] = 'No recipients found for the selected role.';
        header('Location: dashboard.php#notifications');
        exit;
    }

    // Send the notification
    try {
        sendNotification($pdo, $message, $recipients);
        $_SESSION['notification_status'] = 'Notification sent successfully!';
    } catch (Exception $e) {
        $_SESSION['notification_status'] = 'Failed to send notification: ' . $e->getMessage();
    }
    
    // Redirect back to the dashboard
    header('Location: dashboard.php#notifications');
    exit;
}
