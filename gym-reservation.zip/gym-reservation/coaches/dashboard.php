<?php
session_start();
require '../config/database.php';

// Check if user is logged in and is a coach
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'coach') {
    header('Location: login.php');
    exit;
}

$coach_id = $_SESSION['user_id'];

// Fetch coach profile
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$coach_id]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $bio = $_POST['bio'];
    $contact_info = $_POST['contact_info'];

    // Update profile info
    $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, bio = ?, contact_info = ? WHERE id = ?");
    $stmt->execute([$username, $email, $bio, $contact_info, $coach_id]);

    // Update password if provided
    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$hashed_password, $coach_id]);
    }

    // Handle profile picture upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        // Ensure the 'uploads' directory exists and is writable
        $uploads_dir = 'uploads/';
        if (!is_dir($uploads_dir)) {
            mkdir($uploads_dir, 0777, true);
        }

        // Generate a unique name for the uploaded file to avoid conflicts
        $file_name = uniqid() . '_' . basename($_FILES['profile_picture']['name']);
        $file_path = $uploads_dir . $file_name;

        // Move the uploaded file to the 'uploads' directory
        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $file_path)) {
            // Update the profile picture path in the database
            $stmt = $pdo->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
            $stmt->execute([$file_path, $coach_id]);
        } else {
            echo "Failed to upload the file.";
        }
    }

    // Redirect to the profile page
    header('Location: profile.php');
    exit;
}

// Profile picture path
$profile_picture = !empty($profile['profile_picture']) ? htmlspecialchars($profile['profile_picture']) : 'uploads/default-profile.png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Coach Dashboard</title>
    <link rel="stylesheet" href="../css/coaches.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <div class="profile-header">
                <!-- Display the profile picture -->
                <img src="<?= $profile_picture ?>" alt="Profile Picture" width="50px;height:50px;"><br>
                <h1>Welcome, <?= htmlspecialchars($profile['username']) ?></h1>
            </div>
            <div class="dashboard-actions">
                <a href="profile.php" class="button">Profile Info</a>
                <a href="pending_reservations.php" class="button">Pending Reservations</a>
                <a href="notifications.php" class="button">Notifications</a>
                <a href="training_schedule.php" class="button">Training Schedule</a>
                <form method="POST" action="../logout.php" class="logout-form">
                    <button type="submit" class="button">Logout</button>
                </form>
            </div>
        </header>
        <main>
            <h2 class="main-heading">Welcome to the Coach Dashboard</h2>
            <p class="intro-text">Select an option from the menu to manage your reservations, view notifications, or check your training schedule.</p>
        </main>
    </div>
</body>
</html>
