<?php
session_start();
require '../config/database.php';

if ($_SESSION['role'] !== 'coach') {
    header('Location: login.php');
    exit;
}

$coach_id = $_SESSION['user_id'];

// Fetch notifications
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE coach_id = ? AND is_read = 0 ORDER BY created_at DESC");
$stmt->execute([$coach_id]);
$notifications = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Notifications</title>
    <link rel="stylesheet" href="../css/coaches.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <h1>Notifications</h1>
            <a href="dashboard.php" class="button back-button">Back to Dashboard</a>
        </header>
        <main>
            <ul class="notifications-list">
                <?php foreach ($notifications as $notification): ?>
                    <li>
                        <?= htmlspecialchars($notification['message']) ?> - <?= htmlspecialchars($notification['created_at']) ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </main>
    </div>
</body>
</html>
