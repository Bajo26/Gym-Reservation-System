<?php
session_start();
require '../config/database.php';

if ($_SESSION['role'] !== 'coach') {
    header('Location: login.php');
    exit;
}

$coach_id = $_SESSION['user_id'];

// Fetch pending reservations along with reserved workouts
$stmt = $pdo->prepare("
    SELECT r.*, u.username AS member_name, GROUP_CONCAT(w.name SEPARATOR ', ') AS workouts
    FROM reservations r
    JOIN users u ON r.member_id = u.id
    LEFT JOIN reservation_workouts rw ON r.id = rw.reservation_id
    LEFT JOIN workouts w ON rw.workout_id = w.id
    WHERE r.coach_id = ? AND r.status = 'pending'
    GROUP BY r.id
");
$stmt->execute([$coach_id]);
$pending_reservations = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pending Reservations</title>
    <link rel="stylesheet" href="../css/coaches.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <h1>Pending Reservations</h1>
            <a href="dashboard.php" class="button back-button">Back to Dashboard</a>
        </header>
        <main>
            <table class="reservations-table">
                <thead>
                    <tr>
                        <th>Member</th>
                        <th>Reservation Time</th>
                        <th>Workouts</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pending_reservations as $reservation): ?>
                        <tr>
                            <td><?= htmlspecialchars($reservation['member_name']) ?></td>
                            <td><?= htmlspecialchars($reservation['reservation_time']) ?></td>
                            <td><?= htmlspecialchars($reservation['workouts']) ?></td>
                            <td>
                                <form method="POST" action="../process_reservation.php" style="display:inline;">
                                    <input type="hidden" name="reservation_id" value="<?= htmlspecialchars($reservation['id']) ?>">
                                    <button type="submit" name="accept" class="action-button">Accept</button>
                                    <button type="submit" name="decline" class="action-button">Decline</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </main>
    </div>
</body>
</html>
