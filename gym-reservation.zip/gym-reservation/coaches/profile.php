<?php
session_start();
require '../config/database.php';

if ($_SESSION['role'] !== 'coach') {
    header('Location: login.php');
    exit;
}

$coach_id = $_SESSION['user_id'];

// Fetch coach profile info
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$coach_id]);
$coach = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $bio = $_POST['bio'];
    $contact_info = $_POST['contact_info'];
    $gender = $_POST['gender']; // New gender field

    // Update profile info
    $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, bio = ?, contact_info = ?, gender = ? WHERE id = ?");
    $stmt->execute([$username, $email, $bio, $contact_info, $gender, $coach_id]);

    // Update password if provided
    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$hashed_password, $coach_id]);
    }

    // Handle profile picture upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = mime_content_type($_FILES['profile_picture']['tmp_name']);

        if (in_array($file_type, $allowed_types)) {
            $uploads_dir = '../uploads';

            // Ensure the uploads directory exists
            if (!is_dir($uploads_dir)) {
                mkdir($uploads_dir, 0777, true);
            }

            // Generate a unique filename
            $file_extension = pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
            $new_filename = uniqid('profile_', true) . '.' . $file_extension;
            $profile_picture_path = $uploads_dir . '/' . $new_filename;

            // Move the uploaded file to the uploads directory
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $profile_picture_path)) {
                // Update the profile picture path in the database
                $stmt = $pdo->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
                $stmt->execute([$profile_picture_path, $coach_id]);
            } else {
                // Handle file upload error
                echo "Failed to upload profile picture.";
            }
        } else {
            echo "Invalid file type. Only JPG, PNG, and GIF files are allowed.";
        }
    }

    header('Location: profile.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile Info</title>
    <link rel="stylesheet" href="../css/profile.css">
</head>
<body>
    <div class="profile-container">
        <h2>Profile Info</h2>
        <form method="POST" enctype="multipart/form-data">
            <label>Username:</label><br>
            <input type="text" name="username" value="<?= htmlspecialchars($coach['username']) ?>"><br><br>
            
            <label>Email:</label><br>
            <input type="email" name="email" value="<?= htmlspecialchars($coach['email']) ?>"><br><br>

            <label>Password:</label><br>
            <input type="password" name="password" placeholder="Leave blank to keep current password"><br><br>

            <label>Profile Picture:</label><br>
            <img src="<?= htmlspecialchars($coach['profile_picture']) ?>" alt="Profile Picture" width="150"><br>
            <input type="file" name="profile_picture"><br><br>

            <label>Bio:</label><br>
            <textarea name="bio"><?= htmlspecialchars($coach['bio']) ?></textarea><br><br>

            <label>Contact Info:</label><br>
            <input type="text" name="contact_info" value="<?= htmlspecialchars($coach['contact_info']) ?>"><br><br>

            <!-- Gender selection -->
            <label>Gender:</label>
            <select name="gender" required>
                <option value="male" <?= $coach['gender'] == 'male' ? 'selected' : '' ?>>Male</option>
                <option value="female" <?= $coach['gender'] == 'female' ? 'selected' : '' ?>>Female</option>
            </select>
            <br><br>

            <button type="submit">Update Profile</button>
        </form>

        <a href="../coaches/dashboard.php" class="button">Back to Dashboard</a>
    </div>
</body>
</html>
