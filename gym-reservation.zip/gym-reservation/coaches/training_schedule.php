<?php
session_start();
require '../config/database.php';

if ($_SESSION['role'] !== 'coach') {
    header('Location: login.php');
    exit;
}

$coach_id = $_SESSION['user_id'];

// Fetch training schedule along with reservation workouts
$stmt = $pdo->prepare("
    SELECT r.*, u.username AS member_name, GROUP_CONCAT(w.name SEPARATOR ', ') AS workouts
    FROM reservations r
    JOIN users u ON r.member_id = u.id
    LEFT JOIN reservation_workouts rw ON r.id = rw.reservation_id
    LEFT JOIN workouts w ON rw.workout_id = w.id
    WHERE r.coach_id = ? AND r.status = 'accepted'
    GROUP BY r.id
");
$stmt->execute([$coach_id]);
$schedule = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Format events for FullCalendar
$events = array_map(function($session) {
    return [
        'title' => htmlspecialchars($session['member_name']) . ': ' . htmlspecialchars($session['workouts']),
        'start' => htmlspecialchars($session['reservation_time']),
        'color' => '#007bff'  // Set a specific color for scheduled events
    ];
}, $schedule);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Training Schedule</title>
    <link rel="stylesheet" href="../css/coaches.css">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.4/main.min.css" rel="stylesheet">
    <style>
        .calendar-box {
            margin: 20px 0;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }
        .back-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <h1>Training Schedule</h1>
            <a href="dashboard.php" class="button back-button">Back to Dashboard</a>
        </header>
        <main>
            <!-- Calendar Box -->
            <div class="calendar-box">
                <div id="calendar"></div>
            </div>
            
            <!-- Training Schedule Table -->
            <table class="schedule-table">
                <thead>
                    <tr>
                        <th>Member</th>
                        <th>Reservation Time</th>
                        <th>Workouts</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($schedule as $session): ?>
                        <tr>
                            <td><?= htmlspecialchars($session['member_name']) ?></td>
                            <td><?= htmlspecialchars($session['reservation_time']) ?></td>
                            <td><?= htmlspecialchars($session['workouts']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </main>
    </div>

    <!-- Include FullCalendar scripts -->
    <script src="https://cdn.jsdelivr.net/npm/@fullcalendar/core@6.1.4/main.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@6.1.4/main.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');
            
            var events = <?php echo json_encode($events); ?>;

            var calendar = new FullCalendar.Calendar(calendarEl, {
                plugins: ['dayGrid'],
                initialView: 'dayGridMonth',
                events: events,
                eventColor: '#007bff',
                eventTextColor: 'white'
            });
            
            calendar.render();
        });
    </script>
</body>
</html>
