-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 13, 2024 at 04:21 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gym_reservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `notif`
--

CREATE TABLE `notif` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notif`
--

INSERT INTO `notif` (`id`, `message`, `recipient_id`, `created_at`) VALUES
(1, 'hello', 4, '2024-08-11 15:15:41'),
(2, 'hello', 3, '2024-08-11 15:15:41'),
(3, 'hello', 2, '2024-08-11 15:15:41'),
(4, 'hi', 3, '2024-08-11 15:18:44');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `coach_id` int(11) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `coach_id`, `member_id`, `message`, `is_read`, `created_at`) VALUES
(1, 3, NULL, 'Your reservation has been accepted.', NULL, '2024-08-11 13:23:22'),
(2, 3, NULL, 'Your reservation has been accepted.', NULL, '2024-08-12 06:06:12');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `report_name` varchar(255) NOT NULL,
  `report_path` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `coach_id` int(11) DEFAULT NULL,
  `reservation_time` datetime DEFAULT NULL,
  `status` enum('pending','accepted','declined') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `member_id`, `coach_id`, `reservation_time`, `status`, `created_at`) VALUES
(1, 3, 2, '2024-08-30 13:54:00', 'accepted', '2024-08-11 12:51:34'),
(2, 3, 2, '2024-08-23 16:19:00', 'pending', '2024-08-11 16:23:25'),
(3, 3, 2, '2024-08-12 13:19:00', 'pending', '2024-08-12 05:19:37'),
(4, 3, 2, '2024-08-12 13:50:00', 'pending', '2024-08-12 05:50:24'),
(5, 3, 2, '2024-08-12 13:52:00', 'accepted', '2024-08-12 05:52:45'),
(6, 3, 2, '2024-08-12 13:57:00', 'pending', '2024-08-12 05:57:51');

-- --------------------------------------------------------

--
-- Table structure for table `reservation_workouts`
--

CREATE TABLE `reservation_workouts` (
  `id` int(11) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `workout_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservation_workouts`
--

INSERT INTO `reservation_workouts` (`id`, `reservation_id`, `workout_id`) VALUES
(1, 4, 199),
(2, 5, 129),
(3, 5, 130),
(4, 5, 131),
(5, 5, 132),
(6, 5, 133),
(7, 5, 134),
(8, 6, 187);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','coach','member') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `profile_picture` varchar(255) DEFAULT 'default.jpg',
  `bio` text DEFAULT NULL,
  `contact_info` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` enum('male','female') NOT NULL DEFAULT 'male'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created_at`, `profile_picture`, `bio`, `contact_info`, `email`, `gender`) VALUES
(2, 'krieze', '$2y$10$VYTWFqgEZtpC1k.s7Y2P6Oqo40mqe8/Z/J7qbHPujE.dfp3PihF.a', 'coach', '2024-08-11 12:02:00', 'uploads/profile_66bab56634b667.64611523.jpeg', 'im fat', '09068554799', 'fbajo001@gmail.com', 'male'),
(3, 'kiko', '$2y$10$bt4n.138mGkhy.7aVtoy7uZUCzveIbLdHiLEGBJ1AbwK.0YgwjqyK', 'member', '2024-08-11 12:02:18', '../uploads/profile_66baba537c69f2.92718110.jpeg', '', '', '', 'male'),
(4, 'admin', '$2y$10$FOYLtGgbcjRAayxXlMsXMeOaobmGKYR3P5.MjpQnYrKZfN9iw.m4C', 'admin', '2024-08-11 14:44:57', '', 'admin', '09068554799', 'fbajo002@gmail.com', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `workouts`
--

CREATE TABLE `workouts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `workouts`
--

INSERT INTO `workouts` (`id`, `name`, `category`) VALUES
(1, 'Band-Assisted Bench Press', 'Chest'),
(2, 'Bar Dip', 'Chest'),
(3, 'Bench Press', 'Chest'),
(4, 'Bench Press Against Band', 'Chest'),
(5, 'Board Press', 'Chest'),
(6, 'Cable Chest Press', 'Chest'),
(7, 'Close-Grip Bench Press', 'Chest'),
(8, 'Close-Grip Feet-Up Bench Press', 'Chest'),
(9, 'Decline Bench Press', 'Chest'),
(10, 'Decline Push-Up', 'Chest'),
(11, 'Dumbbell Chest Fly', 'Chest'),
(12, 'Dumbbell Chest Press', 'Chest'),
(13, 'Dumbbell Decline Chest Press', 'Chest'),
(14, 'Dumbbell Floor Press', 'Chest'),
(15, 'Dumbbell Pullover', 'Chest'),
(16, 'Feet-Up Bench Press', 'Chest'),
(17, 'Floor Press', 'Chest'),
(18, 'Incline Bench Press', 'Chest'),
(19, 'Incline Dumbbell Press', 'Chest'),
(20, 'Incline Push-Up', 'Chest'),
(21, 'Kettlebell Floor Press', 'Chest'),
(22, 'Kneeling Incline Push-Up', 'Chest'),
(23, 'Kneeling Push-Up', 'Chest'),
(24, 'Machine Chest Fly', 'Chest'),
(25, 'Machine Chest Press', 'Chest'),
(26, 'Pec Deck', 'Chest'),
(27, 'Pin Bench Press', 'Chest'),
(28, 'Push-Up', 'Chest'),
(29, 'Push-Up Against Wall', 'Chest'),
(30, 'Push-Ups With Feet in Rings', 'Chest'),
(31, 'Resistance Band Chest Fly', 'Chest'),
(32, 'Smith Machine Bench Press', 'Chest'),
(33, 'Smith Machine Incline Bench Press', 'Chest'),
(34, 'Standing Cable Chest Fly', 'Chest'),
(35, 'Standing Resistance Band Chest Fly', 'Chest'),
(36, 'Band External Shoulder Rotation', 'Shoulders'),
(37, 'Band Internal Shoulder Rotation', 'Shoulders'),
(38, 'Band Pull-Apart', 'Shoulders'),
(39, 'Barbell Front Raise', 'Shoulders'),
(40, 'Barbell Rear Delt Row', 'Shoulders'),
(41, 'Barbell Upright Row', 'Shoulders'),
(42, 'Behind the Neck Press', 'Shoulders'),
(43, 'Cable Lateral Raise', 'Shoulders'),
(44, 'Cable Rear Delt Row', 'Shoulders'),
(45, 'Dumbbell Front Raise', 'Shoulders'),
(46, 'Dumbbell Horizontal Internal Shoulder Rotation', 'Shoulders'),
(47, 'Dumbbell Horizontal External Shoulder Rotation', 'Shoulders'),
(48, 'Dumbbell Lateral Raise', 'Shoulders'),
(49, 'Dumbbell Rear Delt Row', 'Shoulders'),
(50, 'Dumbbell Shoulder Press', 'Shoulders'),
(51, 'Face Pull', 'Shoulders'),
(52, 'Front Hold', 'Shoulders'),
(53, 'Lying Dumbbell External Shoulder Rotation', 'Shoulders'),
(54, 'Lying Dumbbell Internal Shoulder Rotation', 'Shoulders'),
(55, 'Machine Lateral Raise', 'Shoulders'),
(56, 'Machine Shoulder Press', 'Shoulders'),
(57, 'Monkey Row', 'Shoulders'),
(58, 'Overhead Press', 'Shoulders'),
(59, 'Plate Front Raise', 'Shoulders'),
(60, 'Power Jerk', 'Shoulders'),
(61, 'Push Press', 'Shoulders'),
(62, 'Reverse Cable Flyes', 'Shoulders'),
(63, 'Reverse Dumbbell Flyes', 'Shoulders'),
(64, 'Reverse Machine Fly', 'Shoulders'),
(65, 'Seated Dumbbell Shoulder Press', 'Shoulders'),
(66, 'Seated Barbell Overhead Press', 'Shoulders'),
(67, 'Seated Smith Machine Shoulder Press', 'Shoulders'),
(68, 'Snatch Grip Behind the Neck Press', 'Shoulders'),
(69, 'Squat Jerk', 'Shoulders'),
(70, 'Split Jerk', 'Shoulders'),
(71, 'Barbell Curl', 'Biceps'),
(72, 'Barbell Preacher Curl', 'Biceps'),
(73, 'Bodyweight Curl', 'Biceps'),
(74, 'Cable Curl With Bar', 'Biceps'),
(75, 'Cable Curl With Rope', 'Biceps'),
(76, 'Concentration Curl', 'Biceps'),
(77, 'Dumbbell Curl', 'Biceps'),
(78, 'Dumbbell Preacher Curl', 'Biceps'),
(79, 'Hammer Curl', 'Biceps'),
(80, 'Incline Dumbbell Curl', 'Biceps'),
(81, 'Machine Bicep Curl', 'Biceps'),
(82, 'Spider Curl', 'Biceps'),
(83, 'Barbell Standing Triceps Extension', 'Triceps'),
(84, 'Barbell Lying Triceps Extension', 'Triceps'),
(85, 'Bench Dip', 'Triceps'),
(86, 'Close-Grip Push-Up', 'Triceps'),
(87, 'Dumbbell Lying Triceps Extension', 'Triceps'),
(88, 'Dumbbell Standing Triceps Extension', 'Triceps'),
(89, 'Overhead Cable Triceps Extension', 'Triceps'),
(90, 'Tricep Bodyweight Extension', 'Triceps'),
(91, 'Tricep Pushdown With Bar', 'Triceps'),
(92, 'Tricep Pushdown With Rope', 'Triceps'),
(93, 'Air Squat', 'Legs'),
(94, 'Barbell Hack Squat', 'Legs'),
(95, 'Barbell Lunge', 'Legs'),
(96, 'Barbell Walking Lunge', 'Legs'),
(97, 'Belt Squat', 'Legs'),
(98, 'Body Weight Lunge', 'Legs'),
(99, 'Bodyweight Leg Curl', 'Legs'),
(100, 'Box Squat', 'Legs'),
(101, 'Bulgarian Split Squat', 'Legs'),
(102, 'Chair Squat', 'Legs'),
(103, 'Dumbbell Lunge', 'Legs'),
(104, 'Dumbbell Squat', 'Legs'),
(105, 'Front Squat', 'Legs'),
(106, 'Goblet Squat', 'Legs'),
(107, 'Hack Squat Machine', 'Legs'),
(108, 'Half Air Squat', 'Legs'),
(109, 'Hip Adduction Machine', 'Legs'),
(110, 'Jumping Lunge', 'Legs'),
(111, 'Landmine Hack Squat', 'Legs'),
(112, 'Landmine Squat', 'Legs'),
(113, 'Leg Curl On Ball', 'Legs'),
(114, 'Leg Extension', 'Legs'),
(115, 'Leg Press', 'Legs'),
(116, 'Lying Leg Curl', 'Legs'),
(117, 'Nordic Hamstring Eccentric', 'Legs'),
(118, 'Pause Squat', 'Legs'),
(119, 'Reverse Barbell Lunge', 'Legs'),
(120, 'Romanian Deadlift', 'Legs'),
(121, 'Safety Bar Squat', 'Legs'),
(122, 'Seated Leg Curl', 'Legs'),
(123, 'Shallow Body Weight Lunge', 'Legs'),
(124, 'Side Lunges (Bodyweight)', 'Legs'),
(125, 'Smith Machine Squat', 'Legs'),
(126, 'Squat', 'Legs'),
(127, 'Step Up', 'Legs'),
(128, 'Zercher Squat', 'Legs'),
(129, 'Assisted Chin-Up', 'Back'),
(130, 'Assisted Pull-Up', 'Back'),
(131, 'Back Extension', 'Back'),
(132, 'Banded Muscle-Up', 'Back'),
(133, 'Barbell Row', 'Back'),
(134, 'Barbell Shrug', 'Back'),
(135, 'Block Clean', 'Back'),
(136, 'Block Snatch', 'Back'),
(137, 'Cable Close Grip Seated Row', 'Back'),
(138, 'Cable Wide Grip Seated Row', 'Back'),
(139, 'Chin-Up', 'Back'),
(140, 'Clean', 'Back'),
(141, 'Clean and Jerk', 'Back'),
(142, 'Deadlift', 'Back'),
(143, 'Deficit Deadlift', 'Back'),
(144, 'Dumbbell Deadlift', 'Back'),
(145, 'Dumbbell Row', 'Back'),
(146, 'Dumbbell Shrug', 'Back'),
(147, 'Floor Back Extension', 'Back'),
(148, 'Good Morning', 'Back'),
(149, 'Hang Clean', 'Back'),
(150, 'Hang Power Clean', 'Back'),
(151, 'Hang Power Snatch', 'Back'),
(152, 'Hang Snatch', 'Back'),
(153, 'Inverted Row', 'Back'),
(154, 'Inverted Row with Underhand Grip', 'Back'),
(155, 'Jefferson Curl', 'Back'),
(156, 'Jumping Muscle-Up', 'Back'),
(157, 'Kettlebell Swing', 'Back'),
(158, 'Lat Pulldown With Pronated Grip', 'Back'),
(159, 'Lat Pulldown With Supinated Grip', 'Back'),
(160, 'Muscle-Up (Bar)', 'Back'),
(161, 'Muscle-Up (Rings)', 'Back'),
(162, 'One-Handed Cable Row', 'Back'),
(163, 'One-Handed Lat Pulldown', 'Back'),
(164, 'Pause Deadlift', 'Back'),
(165, 'Pendlay Row', 'Back'),
(166, 'Power Clean', 'Back'),
(167, 'Power Snatch', 'Back'),
(168, 'Pull-Up', 'Back'),
(169, 'Pull-Up With a Neutral Grip', 'Back'),
(170, 'Rack Pull', 'Back'),
(171, 'Ring Pull-Up', 'Back'),
(172, 'Ring Row', 'Back'),
(173, 'Seal Row', 'Back'),
(174, 'Seated Machine Row', 'Back'),
(175, 'Snatch', 'Back'),
(176, 'Snatch Grip Deadlift', 'Back'),
(177, 'Stiff-Legged Deadlift', 'Back'),
(178, 'Straight Arm Lat Pulldown', 'Back'),
(179, 'Sumo Deadlift', 'Back'),
(180, 'T-Bar Row', 'Back'),
(181, 'Trap Bar Deadlift With High Handles', 'Back'),
(182, 'Trap Bar Deadlift With Low Handles', 'Back'),
(183, 'Banded Side Kicks', 'Glutes'),
(184, 'Cable Pull Through', 'Glutes'),
(185, 'Clamshells', 'Glutes'),
(186, 'Dumbbell Romanian Deadlift', 'Glutes'),
(187, 'Dumbbell Frog Pumps', 'Glutes'),
(188, 'Fire Hydrants', 'Glutes'),
(189, 'Frog Pumps', 'Glutes'),
(190, 'Glute Bridge', 'Glutes'),
(191, 'Hip Abduction Against Band', 'Glutes'),
(192, 'Hip Abduction Machine', 'Glutes'),
(193, 'Hip Thrust', 'Glutes'),
(194, 'Lying Hip Abduction', 'Glutes'),
(195, 'Single-Leg Romanian Deadlift', 'Glutes'),
(196, 'Single-Leg Hip Thrust', 'Glutes'),
(197, 'Squat Pulse', 'Glutes'),
(198, 'Ab Wheel Rollout', 'Core'),
(199, 'Bicycle Crunch', 'Core'),
(200, 'Body Hollow', 'Core'),
(201, 'Body Hold', 'Core'),
(202, 'Cable Ab Pulldown', 'Core'),
(203, 'Crunch', 'Core'),
(204, 'Decline Sit-Up', 'Core'),
(205, 'Dumbbell Side Bend', 'Core'),
(206, 'Flutter Kick', 'Core'),
(207, 'Hanging Leg Raise', 'Core'),
(208, 'Hanging Straight Leg Raise', 'Core'),
(209, 'Hanging Windshield Wiper', 'Core'),
(210, 'Hip Flexion March', 'Core'),
(211, 'Hollow Body Hold', 'Core'),
(212, 'Kneeling Ab Wheel Rollout', 'Core'),
(213, 'Lying Leg Raise', 'Core'),
(214, 'Machine Ab Crunch', 'Core'),
(215, 'Oblique Crunch', 'Core'),
(216, 'Oblique Sit-Up', 'Core'),
(217, 'Overhead Sit-Up', 'Core'),
(218, 'Plank', 'Core'),
(219, 'Plank With Arm Raise', 'Core'),
(220, 'Plank With Leg Raise', 'Core'),
(221, 'Plate Ab Pulldown', 'Core'),
(222, 'Reverse Crunch', 'Core'),
(223, 'Russian Twist', 'Core'),
(224, 'Seated Knee Tuck', 'Core'),
(225, 'Side Crunch', 'Core'),
(226, 'Side Leg Raise', 'Core'),
(227, 'Sit-Up', 'Core'),
(228, 'Sitting Knee Tuck', 'Core'),
(229, 'Stir The Pot', 'Core'),
(230, 'Suitcase Carry', 'Core'),
(231, 'Toe Touches', 'Core'),
(232, 'Weighted Crunch', 'Core'),
(233, 'Windshield Wiper', 'Core');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `notif`
--
ALTER TABLE `notif`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservation_workouts`
--
ALTER TABLE `reservation_workouts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reservation_id` (`reservation_id`),
  ADD KEY `workout_id` (`workout_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `workouts`
--
ALTER TABLE `workouts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `notif`
--
ALTER TABLE `notif`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `reservation_workouts`
--
ALTER TABLE `reservation_workouts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `workouts`
--
ALTER TABLE `workouts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=235;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservation_workouts`
--
ALTER TABLE `reservation_workouts`
  ADD CONSTRAINT `reservation_workouts_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`),
  ADD CONSTRAINT `reservation_workouts_ibfk_2` FOREIGN KEY (`workout_id`) REFERENCES `workouts` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
