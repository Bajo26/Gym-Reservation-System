<?php
$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? AND read_status = 0");
$stmt->execute([$user_id]);
$notifications = $stmt->fetchAll();

foreach ($notifications as $notification) {
    echo "<p>{$notification['message']}</p>";
    $stmt = $pdo->prepare("UPDATE notifications SET read_status = 1 WHERE id = ?");
    $stmt->execute([$notification['id']]);
}
?>
