<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$role = $_SESSION['role'];

switch ($role) {
    case 'admin':
        header('Location: admin/dashboard.php');
        break;
    case 'coach':
        header('Location: coaches/dashboard.php');
        break;
    case 'member':
        header('Location: members/dashboard.php');
        break;
    default:
        echo "Invalid role!";
}
exit;
?>
