<?php
session_start();
if ($_SESSION['role'] !== 'member') {
    header('Location: ../login.php');
    exit;
}
require '../config/database.php';

$member_id = $_SESSION['user_id'];

// Fetch available coaches
$stmt = $pdo->prepare("SELECT * FROM users WHERE role = 'coach'");
$stmt->execute();
$coaches = $stmt->fetchAll();

// Fetch available workouts, grouped by category
$stmt = $pdo->prepare("SELECT category, name, id FROM workouts ORDER BY category, name");
$stmt->execute();
$workouts = $stmt->fetchAll(PDO::FETCH_GROUP|PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Choose a Coach</title>
    <link rel="stylesheet" href="../css/members.css">
    <style>
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .category-buttons {
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 20px;
            gap: 10px;
        }
        .category-button {
            padding: 10px;
            border: 1px solid #ccc;
            background-color: #007bff; /* Blue background */
            color: white; /* White text color */
            text-align: center;
            cursor: pointer;
            font-weight: bold;
            border-radius: 5px;
            transition: background-color 0.3s;
            flex: 1 1 calc(100% / 6 - 10px); /* Adjust to fit 6 buttons horizontally */
        }
        .category-button:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
        .workout-select {
            margin-top: 20px;
        }
        .workout-select label {
            display: block;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .workout-select .workout-list {
            max-height: 300px;
            overflow-y: auto;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
        }
        .workout-select input[type="checkbox"] {
            margin-right: 10px;
        }
        .workout-select .checkbox-label {
            display: block;
            margin-bottom: 5px;
        }
        .selected-workouts {
            margin-top: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            background-color: #f9f9f9;
        }
        .selected-workouts ul {
            list-style: none;
            padding: 0;
        }
        .selected-workouts li {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 5px;
            padding: 5px;
            border-bottom: 1px solid #ddd;
        }
        .selected-workouts li button {
            background: none;
            border: none;
            color: red;
            cursor: pointer;
        }
        .selected-workouts li button:hover {
            text-decoration: underline;
        }
        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Choose a Coach</h1>
        
        <form method="POST" action="reserve_coach.php" id="reservationForm">
            <label for="coach_id">Select Coach:</label>
            <select name="coach_id" id="coach_id" required>
                <option value="">Select a coach</option>
                <?php foreach ($coaches as $coach): ?>
                    <option value="<?= htmlspecialchars($coach['id']) ?>"><?= htmlspecialchars($coach['username']) ?></option>
                <?php endforeach; ?>
            </select>

            <label for="reservation_time">Reservation Time:</label>
            <input type="datetime-local" name="reservation_time" id="reservation_time" required>

            <label for="workouts">Select Workouts:</label>
            <div class="category-buttons">
                <?php foreach (array_keys($workouts) as $category): ?>
                    <button type="button" class="category-button" data-category="<?= htmlspecialchars($category) ?>"><?= htmlspecialchars($category) ?></button>
                <?php endforeach; ?>
            </div>

            <div class="workout-select">
                <label>Select Workouts:</label>
                <div class="workout-list" id="workout_list">
                    <!-- Checkboxes will be populated by JavaScript -->
                </div>
                <div class="error" id="error-message"></div>
            </div>

            <div class="selected-workouts">
                <label>Selected Workouts:</label>
                <ul id="selected_workouts_list">
                    <!-- Selected workouts will appear here -->
                </ul>
            </div>

            <button type="submit">Reserve</button>
        </form>
        
        <a href="dashboard.php" class="button">Back to Dashboard</a>
    </div>

    <script>
        const workouts = <?= json_encode($workouts) ?>;
        const workoutList = document.getElementById('workout_list');
        const selectedWorkoutsList = document.getElementById('selected_workouts_list');
        const buttons = document.querySelectorAll('.category-button');
        const reservationForm = document.getElementById('reservationForm');
        const errorMessage = document.getElementById('error-message');

        function populateWorkouts(category) {
            workoutList.innerHTML = ''; // Clear previous checkboxes
            const categoryWorkouts = workouts[category] || [];
            categoryWorkouts.forEach(workout => {
                const checkboxWrapper = document.createElement('div');
                checkboxWrapper.classList.add('checkbox-label');
                
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.name = 'workouts[]';
                checkbox.value = workout.id;
                checkbox.classList.add('workout-checkbox');
                
                const label = document.createElement('label');
                label.textContent = workout.name;
                
                checkboxWrapper.appendChild(checkbox);
                checkboxWrapper.appendChild(label);
                workoutList.appendChild(checkboxWrapper);
            });
        }

        function addWorkoutToSelection(id, name) {
            const existingWorkout = document.getElementById(`workout-${id}`);
            if (!existingWorkout) {
                const listItem = document.createElement('li');
                listItem.id = `workout-${id}`;
                
                const text = document.createElement('span');
                text.textContent = name;
                
                const removeButton = document.createElement('button');
                removeButton.textContent = 'X';
                removeButton.onclick = () => removeWorkout(id);

                listItem.appendChild(text);
                listItem.appendChild(removeButton);
                selectedWorkoutsList.appendChild(listItem);
            }
        }

        function removeWorkout(id) {
            const listItem = document.getElementById(`workout-${id}`);
            if (listItem) {
                listItem.remove();
                document.querySelector(`input[value="${id}"]`).checked = false;
            }
        }

        buttons.forEach(button => {
            button.addEventListener('click', () => {
                const category = button.getAttribute('data-category');
                populateWorkouts(category);
            });
        });

        workoutList.addEventListener('change', (event) => {
            const checkbox = event.target;
            if (checkbox.type === 'checkbox') {
                const workoutId = checkbox.value;
                const workoutName = checkbox.nextElementSibling.textContent;

                if (checkbox.checked) {
                    if (selectedWorkoutsList.children.length < 5) {
                        addWorkoutToSelection(workoutId, workoutName);
                    } else {
                        checkbox.checked = false;
                        errorMessage.textContent = 'You can only select up to 5 workouts.';
                    }
                } else {
                    removeWorkout(workoutId);
                }
            }
        });

        reservationForm.addEventListener('submit', (event) => {
            const selectedWorkouts = document.querySelectorAll('#selected_workouts_list li');
            if (selectedWorkouts.length < 1 || selectedWorkouts.length > 5) {
                errorMessage.textContent = 'You must select between 1 and 5 workouts.';
                event.preventDefault(); // Prevent form submission
            } else {
                errorMessage.textContent = ''; // Clear error message
            }
        });

        // Optionally, you can add a default category to show upon loading the page
        if (buttons.length > 0) {
            buttons[0].click(); // Simulate a click on the first category button to show its workouts
        }
    </script>
</body>
</html>
