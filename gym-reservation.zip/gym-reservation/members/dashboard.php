<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'member') {
    header('Location: ../login.php');
    exit;
}

require '../config/database.php';

$member_id = $_SESSION['user_id'];

// Fetch profile information
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$member_id]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC);

// Profile picture path
$profile_picture = !empty($profile['profile_picture']) ? '../uploads/' . htmlspecialchars($profile['profile_picture']) : '../uploads/default-profile.png';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Member Dashboard</title>
    <link rel="stylesheet" href="../css/members.css">
</head>
<body>
    <div class="container">
        <header class="header">
            <!-- Display the profile picture -->
            <img src="<?= $profile_picture ?>" alt="Profile Picture" width="100" height="100"><br></br>
            <h1>Welcome, <?= htmlspecialchars($profile['username']) ?>!</h1>
            <nav class="top-nav">
                <a href="choose_coach.php">Choose a Coach</a>
                <a href="my_reservations.php">My Reservations</a>
                <a href="notifications.php">Notifications</a>
                <a href="profile.php">Your Profile</a>
                <a href="../logout.php" class="logout-button">Logout</a>
            </nav>
        </header>
        
        <div class="intro">
            We're glad to have you at the gym. Here you can manage your reservations, view your notifications, and update your profile.
        </div>
    </div>
</body>
</html>
