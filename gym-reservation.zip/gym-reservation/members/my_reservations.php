<?php
session_start();
if ($_SESSION['role'] !== 'member') {
    header('Location: ../login.php');
    exit;
}
require '../config/database.php';

$member_id = $_SESSION['user_id'];

// Fetch member's reservations along with reserved workouts
$stmt = $pdo->prepare("
    SELECT r.*, u.username AS coach_name, GROUP_CONCAT(w.name SEPARATOR ', ') AS workouts
    FROM reservations r
    JOIN users u ON r.coach_id = u.id
    LEFT JOIN reservation_workouts rw ON r.id = rw.reservation_id
    LEFT JOIN workouts w ON rw.workout_id = w.id
    WHERE r.member_id = ?
    GROUP BY r.id
");
$stmt->execute([$member_id]);
$reservations = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Reservations</title>
    <link rel="stylesheet" href="../css/members.css">
</head>
<body>
    <div class="container">
        <h1>Your Reservations</h1>
        <table class="reservations-table">
            <thead>
                <tr>
                    <th>Coach Name</th>
                    <th>Reservation Time</th>
                    <th>Workouts</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reservations as $reservation): ?>
                    <tr>
                        <td><?= htmlspecialchars($reservation['coach_name']) ?></td>
                        <td><?= htmlspecialchars($reservation['reservation_time']) ?></td>
                        <td><?= htmlspecialchars($reservation['workouts']) ?></td>
                        <td><?= ucfirst(htmlspecialchars($reservation['status'])) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="dashboard.php" class="button back-button">Back to Dashboard</a>
    </div>
</body>
</html>
