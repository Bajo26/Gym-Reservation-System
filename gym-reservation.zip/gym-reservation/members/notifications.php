<?php
session_start();
if ($_SESSION['role'] !== 'member') {
    header('Location: ../login.php');
    exit;
}
require '../config/database.php';

$member_id = $_SESSION['user_id'];

// Fetch notifications
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE member_id = ? AND is_read = 0 ORDER BY created_at DESC");
$stmt->execute([$member_id]);
$notifications = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Notifications</title>
    <link rel="stylesheet" href="../css/members.css">
    
</head>
<body>
    <div class="container">
        <h1>Notifications</h1>
        
        <div class="notifications">
            <ul>
                <?php foreach ($notifications as $notification): ?>
                    <li><?= $notification['message'] ?> - <?= $notification['created_at'] ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <a href="dashboard.php" class="button">Back to Dashboard</a>
    </div>
</body>
</html>
