<?php
session_start();
if ($_SESSION['role'] !== 'member') {
    header('Location: ../login.php');
    exit;
}
require '../config/database.php';

$member_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and process form submission
    $coach_id = $_POST['coach_id'];
    $reservation_time = $_POST['reservation_time'];
    $workouts = isset($_POST['workouts']) ? $_POST['workouts'] : [];

    if ($coach_id && $reservation_time && !empty($workouts)) {
        // Insert reservation into the database
        $stmt = $pdo->prepare("INSERT INTO reservations (member_id, coach_id, reservation_time, status) VALUES (?, ?, ?, 'pending')");
        $result = $stmt->execute([$member_id, $coach_id, $reservation_time]);

        if ($result) {
            $reservation_id = $pdo->lastInsertId();

            // Insert selected workouts into reservation_workouts table
            foreach ($workouts as $workout_id) {
                $stmt = $pdo->prepare("INSERT INTO reservation_workouts (reservation_id, workout_id) VALUES (?, ?)");
                $stmt->execute([$reservation_id, $workout_id]);
            }

            header('Location: my_reservations.php');
            exit;
        } else {
            $error = "There was an error with your reservation. Please try again.";
        }
    } else {
        $error = "Please fill out all fields and select at least one workout.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reserve a Coach</title>
    <link rel="stylesheet" href="../css/members.css">
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>Reserve a Coach</h1>
            <nav class="top-nav">
                <a href="choose_coach.php">Choose a Coach</a>
                <a href="my_reservations.php">My Reservations</a>
                <a href="notifications.php">Notifications</a>
                <a href="profile.php">Your Profile</a>
                <a href="../logout.php" class="logout-button">Logout</a>
            </nav>
        </header>
        
        <div class="intro">
            <form method="POST" action="reserve_coach.php">
                <label for="coach_id">Select Coach:</label>
                <select name="coach_id" id="coach_id" required>
                    <option value="">Select a coach</option>
                    <?php foreach ($coaches as $coach): ?>
                        <option value="<?= htmlspecialchars($coach['id']) ?>"><?= htmlspecialchars($coach['username']) ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="reservation_time">Reservation Time:</label>
                <input type="datetime-local" name="reservation_time" id="reservation_time" required>

                <label for="workouts">Select Workouts:</label>
                <?php foreach ($workouts as $workout): ?>
                    <div>
                        <input type="checkbox" name="workouts[]" value="<?= htmlspecialchars($workout['id']) ?>">
                        <label><?= htmlspecialchars($workout['name']) ?></label>
                    </div>
                <?php endforeach; ?>

                <button type="submit">Reserve</button>
                <?php if (isset($error)): ?>
                    <p class="error"><?= htmlspecialchars($error) ?></p>
                <?php endif; ?>
            </form>
            <a href="dashboard.php" class="button">Back to Dashboard</a>
        </div>
    </div>
</body>
</html>
