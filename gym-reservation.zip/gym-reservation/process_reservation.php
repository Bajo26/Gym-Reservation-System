<?php
session_start();
require 'config/database.php';

if ($_SESSION['role'] !== 'coach') {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $reservation_id = $_POST['reservation_id'];
    $action = isset($_POST['accept']) ? 'accepted' : 'declined';

    // Update reservation status
    $stmt = $pdo->prepare("UPDATE reservations SET status = ? WHERE id = ?");
    $stmt->execute([$action, $reservation_id]);

    // Notify the member
    $stmt = $pdo->prepare("SELECT member_id FROM reservations WHERE id = ?");
    $stmt->execute([$reservation_id]);
    $member_id = $stmt->fetchColumn();

    $message = $action == 'accepted' ? "Your reservation has been accepted." : "Your reservation has been declined.";
    $stmt = $pdo->prepare("INSERT INTO notifications (coach_id, message) VALUES (?, ?)");
    $stmt->execute([$member_id, $message]);

    header('Location: coaches/dashboard.php');
    exit;
}
?>
