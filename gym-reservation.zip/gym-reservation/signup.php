<?php
session_start();
require 'config/database.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['new_username'];
    $password = $_POST['new_password'];
    $email = $_POST['email'];
    $contact_info = $_POST['contact_info'];
    $bio = $_POST['bio'];
    $profile_picture = $_FILES['profile_picture']['name'];
    $role = $_POST['role'];
    $gender = $_POST['gender']; // New gender field

    // Check if username already exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        $error = "Username already exists!";
    } else {
        // Handle profile picture upload
        $upload_dir = 'uploads/';
        $upload_file = $upload_dir . basename($_FILES['profile_picture']['name']);
        move_uploaded_file($_FILES['profile_picture']['tmp_name'], $upload_file);

        // Create new user
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT INTO users (username, password, email, contact_info, bio, profile_picture, role, gender) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$username, $hashed_password, $email, $contact_info, $bio, $profile_picture, $role, $gender]);

        // Redirect back to login
        header('Location: login.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Signup</title>
    <link rel="stylesheet" href="css/signup.css">
</head>
<body>
    <div class="signup-container">
        <h2>Signup</h2>
        <form method="POST" action="signup.php" enctype="multipart/form-data">
            <input type="text" name="new_username" placeholder="Username" required>
            <input type="password" name="new_password" placeholder="Password" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="contact_info" placeholder="Contact Info">
            <textarea name="bio" placeholder="Bio"></textarea>
            <input type="file" name="profile_picture" accept="image/*">
            <select name="role" required>
                <option value="coach">Coach</option>
                <option value="member">Member</option>
            </select>
            <!-- Gender selection -->
            <label>Gender:</label>
            <select name="gender" required>
                <option value="male">Male</option>
                <option value="female">Female</option>
            </select>
            <button type="submit">Signup</button>
        </form>

        <?php if ($error): ?>
            <p class="error"><?= $error ?></p>
        <?php endif; ?>

        <p><a href="login.php">Back to Login</a></p>
    </div>
</body>
</html>
